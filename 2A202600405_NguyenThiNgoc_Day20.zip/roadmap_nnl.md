# TrustLayerAI — Now / Next / Later Roadmap

## NOW
**Vấn đề:** Đội IT và security không có cách kiểm định tính chính xác và an toàn của chatbot nội bộ và luồng RAG/enterprise search tại một nơi.
**Đang code:** Xây hệ thống audit quality score cho chatbot, RAG và enterprise search, thu thập câu hỏi/trả lời từ Slack/Teams và hiển thị báo cáo chất lượng định kỳ.

**Vấn đề:** Quản lý không thể so sánh hiệu suất, compliance và trải nghiệm giữa các chatbot nội bộ và các luồng search nội bộ.
**Đang code:** Làm benchmark dashboard cho phép so sánh bot và enterprise search theo bộ phận, nền tảng và chỉ số an toàn.

## NEXT
**Vấn đề:** Khi chatbot trả lời sai hoặc vi phạm chính sách, bộ phận support chỉ biết sau khi người dùng báo cáo.
**Sẽ làm:** Thêm real-time incident alerting cho các câu trả lời có rủi ro cao hoặc sai lệch dữ liệu, gửi cảnh báo đến owner và security.

**Vấn đề:** Ban lãnh đạo chưa có thước đo ROI rõ ràng cho đầu tư chatbot nội bộ.
**Sẽ làm:** Thêm KPI dashboard tập trung vào adoption, satisfaction và reduction in manual handling.

## LATER
**Vấn đề:** Doanh nghiệp muốn tự động tối ưu chatbot dựa trên dữ liệu audit, nhưng cần nhiều dữ liệu thực tế và đánh giá kỹ thuật chuyên sâu.
**Có thể làm:** Nghiên cứu mô-đun recommendation engine gợi ý cải thiện prompt/training data, nhưng có thể cắt nếu chưa đủ pilot evidence.
