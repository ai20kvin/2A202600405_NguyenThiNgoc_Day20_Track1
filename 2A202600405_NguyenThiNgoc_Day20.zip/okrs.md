# TrustLayerAI — OKRs cho quý tiếp theo

## Objective
Giúp doanh nghiệp tin tưởng và quản lý hiệu quả mọi chatbot nội bộ và luồng RAG/Enterprise Search.

## Key Results
- KR1 (Leading): 25 enterprise chatbot teams sử dụng TrustLayerAI audit dashboard ít nhất 2 lần/tuần.
- KR2 (Lagging): Đạt 12 paying enterprise customers với MRR 480.000.000 VND.
- KR3 (Quality): NPS ≥ 55 và churn khách hàng pilot ≤ 4%/tháng.

### Giải thích
- KR1 đo hành vi khách hàng (user behavior) để dự báo adoption.
- KR2 đo kết quả doanh thu thực tế, chứng minh product-market fit.
- KR3 đảm bảo growth bền vững và quản lý chất lượng dịch vụ.
