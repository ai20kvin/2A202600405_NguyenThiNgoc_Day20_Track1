# TrustLayerAI — Dependency Map + Critical Path

## Dependency 1: LLM evaluation provider
**Worst-case:** OpenAI hoặc Anthropic thay đổi API, tăng giá 5x hoặc giới hạn rate khiến không thể thực hiện audit quality scoring.
**Plan B:** Mua abstraction layer cho LLM API. Hiện có code adapter cho OpenAI, Anthropic và Gemini. Với cache score cho 70% câu hỏi lặp lại, có thể chuyển vendor trong <24h.
**Cost:** 2 tuần dev để hoàn thiện adapter và cache fallback. Nếu cần, duy trì 2 provider song song trong pilot.

## Dependency 2: Slack / Microsoft Teams API access and enterprise search logs
**Worst-case:** Slack/Teams thay đổi permission policy hoặc khách hàng không cho phép agent direct access, hoặc hệ thống enterprise search từ chối truy cập log RAG.
**Plan B:** Hỗ trợ ingest transcript và search logs qua secure webhook/file upload và build connector generic cho API. Nếu API bị giới hạn, dùng thư mục SFTP/secure upload để nhận log.
**Cost:** 1.5 tuần dev để add secure ingestion path và 1 tuần để hoàn thiện encryption/SSO verify.

## Dependency 3: Enterprise privacy & identity
**Worst-case:** Azure AD / Okta policy cấm truy cập dữ liệu chatbot nội bộ hoặc yêu cầu audit cao hơn.
**Plan B:** Chuẩn hóa mô hình dữ liệu chỉ lấy metadata và câu trả lời đã ẩn danh. Sẵn sàng triển khai SAML/SCIM và hỗ trợ file export GDPR-style. Nếu SSO bị chặn, dùng secure API token + audit log.
**Cost:** 2 tuần dev để hoàn thiện security review, 1 tuần chuẩn bị tài liệu compliance.

## Critical Path
1. Legal / Privacy Review for internal chatbot data
2. Secure Data Ingestion pipeline (Slack/Teams/Upload)
3. LLM evaluation pipeline + compliance scoring
4. Dashboard integration + alerting logic
5. Pilot onboarding + feedback loop

### Critical Path analysis
- **Critical tasks:** Legal review → Data ingestion → Model evaluation → Dashboard integration → Pilot onboarding.
- **Non-critical tasks:** UI polish, marketing landing page, documentation copy có thể song song.
- **Buffer tasks:** Thiết kế thương hiệu, training materials và PRM có thể lùi sau launch nếu cần.

## Risk notes
- Nếu OpenAI và Slack API cùng lúc gặp sự cố, Plan B layer vẫn còn chain bằng cách switch vendor và dùng secure upload path.
- Legal/compliance nằm trên Critical Path vì đây là rào cản quyết định với mọi enterprise customer.
