# TrustLayerAI — RICE Matrix

## Product context
TrustLayerAI giúp doanh nghiệp đánh giá chất lượng, compliance và hiệu suất của chatbot nội bộ và các hệ thống RAG/Enterprise Search. Mục tiêu là cung cấp audit score, benchmark và cảnh báo rủi ro trước khi chatbot hoặc hệ thống tìm kiếm nội bộ gây sự cố, trả lời sai, hoặc vi phạm chính sách.

## 5 core features
| Feature | Reach | Impact | Confidence | Effort (PM) | RICE Score |
|---|---|---|---|---|---|
| 1. Automated Chatbot & RAG Quality Audit | 5,000 | 2.0 | 0.8 | 2.0 | 4,000 |
| 2. Compliance & Safety Scorecard | 3,000 | 3.0 | 0.5 | 3.0 | 1,500 |
| 3. Benchmarking Dashboard for internal bots and enterprise search | 2,500 | 1.0 | 0.8 | 1.5 | 1,333 |
| 4. Real-time Incident Alerting | 2,000 | 2.0 | 0.5 | 2.5 | 800 |
| 5. Internal Knowledge Coverage Report | 1,200 | 1.0 | 0.5 | 1.5 | 400 |

### Giải thích điểm
- **Automated Chatbot & RAG Quality Audit**: core value, giúp team IT/security đánh giá toàn bộ chatbot nội bộ và hệ thống RAG/enterprise search ngay trong dashboard. Confidence 80% do đã phỏng vấn 6 khách hàng pilot.
- **Compliance & Safety Scorecard**: giá trị lớn nhưng còn uncertainty về tiêu chuẩn compliance nội bộ; nên Confidence 50%.
- **Benchmarking Dashboard**: quick win cho các leader muốn so sánh hiệu suất chatbot và enterprise search theo bộ phận và nền tảng.
- **Real-time Incident Alerting**: cần nhưng implementation phức tạp, nên effort cao và confidence trung bình.
- **Internal Knowledge Coverage Report**: ít giá trị hơn ngay giai đoạn đầu, nên là non-starter nếu cần cắt scope.

## 2x2 Value-Effort Matrix

```
              Effort
            Low         High
          ┌────────┬────────┐
     High │ Quick  │Strategic│
          │ Wins   │ Bets    │
   Value  ├────────┼────────┤
     Low  │ Fill-  │ Non-    │
          │ ins    │ starters│
          └────────┴────────┘
```

- Quick Wins: Automated Chatbot & RAG Quality Audit, Benchmarking Dashboard for internal bots and enterprise search
- Strategic Bet: Compliance & Safety Scorecard, Real-time Incident Alerting
- Fill-ins: (không có feature low value + low effort rõ ràng)
- Non-starter: Internal Knowledge Coverage Report

### Analysis
- **Quick Win**: Audit và Dashboard cho phép ship giá trị rõ ràng ngay, giúp team chứng minh lợi ích với khách enterprise.
- **Strategic Bet**: Compliance scorecard và alerting xây dựng moat và làm khó đối thủ, nhưng cần đầu tư thêm và test kỹ.
- **Non-starter**: Knowledge Coverage Report hiện chưa đủ evidence để justify effort; nên đặt vào backlog later hoặc bỏ khi thiếu nguồn lực.
